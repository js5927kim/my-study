package com.kh.model.dao;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

import com.kh.model.Game;

public class GameDAO {
	
	private List<Game> games = new ArrayList<>();
	
	
	
	public boolean insert(Game game) {
		
		
		for(Game g : games) {
			if(g.getName().equals(game.getName())) {
				return false;
			}
		}
		games.add(game);
		return true;
		
		
		
	}
	
	public List<Game> selectAll(){
		return games;
	}
	
	public Game update(String name, Game game) {
		
		for(int i = 0; i<games.size(); i++) {
			
			Game g = games.get(i);
			if(g.getName().equals(name)) {
				return games.set(i, game);
			}
			
		}
		return null;
		
		
	}
	
	public boolean delete(String name) {
		
		for (int i =0; i<games.size(); i++) {
			if(games.get(i).getName().equals(name)) {
				games.remove(i);
				return true;
			}
			
		}
		return false;
		
	}
	
	public void save() {
		
	}
	
	public void load() {
		
	}

}
