package com.kh.model;

public class Game {
	
	private String name;
	private String maker;
	private String genre;
	
	public Game() {
		
	}
	
	
	public Game(String name, String maker, String genre) {
		this.name = name;
		this.maker = maker;
		this.genre = genre;
	}
	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the maker
	 */
	public String getMaker() {
		return maker;
	}
	/**
	 * @param maker the maker to set
	 */
	public void setMaker(String maker) {
		this.maker = maker;
	}
	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}
	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}


	@Override
	public String toString() {
		return String.format("[게임정보] \n"
				+ "이름  : %s \n"
				+ "제작사 : %s \n"
				+ "장르  : %s \n", name,maker,genre) ;
	}
	
	
	
	
}
