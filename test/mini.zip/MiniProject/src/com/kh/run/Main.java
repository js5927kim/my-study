package com.kh.run;

import com.kh.view.GameView;

public class Main {

	public static void main(String[] args) {
		
		GameView view = new GameView();
		
		view.showMenu();
		
		
	}

}
