package com.kh.controller;

import java.util.List;

import com.kh.model.Game;
import com.kh.model.dao.GameDAO;

public class GameController {
	
	private Game game = new Game();
	private GameDAO dao = new GameDAO();
	
	public boolean add(String name, String maker, String genre) {
		Game game = new Game(name, maker, genre);
		return dao.insert(game);
	}
	
	public List<Game> selectAll(){
		return dao.selectAll();
	}
	
	public boolean delete(String name) {
		return dao.delete(name);
	}
	
	public Game update(String name, Game game) {
		return dao.update(name, game);
	}
	
	
	public List<Game> list;
		

	
}
