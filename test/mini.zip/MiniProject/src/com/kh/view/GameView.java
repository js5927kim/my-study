package com.kh.view;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.kh.controller.GameController;
import com.kh.model.Game;

public class GameView {

	private GameController controller = new GameController();
	private Scanner sc = new Scanner(System.in);

	public void showMenu() {

		while (true) {
			System.out.println("=======게임 관리=======");
			System.out.println("1. 게임 목록");
			System.out.println("2. 게임 추가");
			System.out.println("3. 게임 삭제");
			System.out.println("4. 게임 정보 수정");
			System.out.println("9. 종료");
			System.out.printf("번호 입력 : ");

			try {

				int menu = sc.nextInt();
				sc.nextLine();

				switch (menu) {
				case 1:
					printAll();
					break;
				case 2:
					addGame();
					break;
				case 3:
					deleteGame();
					break;
				case 9:
					System.out.println("--프로그램 종료--");
					return;
				default:
					System.out.println("올바르지 않은 번호입니다.");
				}

			} catch (InputMismatchException e) {
				System.out.println("숫자를 입력해주세요");
				sc.nextLine();
			}

		}

	}

	public void printAll() {

		List<Game> allGames = controller.selectAll();

		System.out.println("----게임 목록----");
		if (allGames.isEmpty()) {
			System.out.println("등록된 게임이 없습니다");
		} else {
			for (int i = 0; i < allGames.size(); i++) {
				Game game = allGames.get(i);
				System.out.println(game);
			}
		}

	}

	public void addGame() {
		System.out.println("------게임 추가-----");
		System.out.print("게임 이름 :");
		String name = sc.nextLine();
		System.out.print("게임 개발사 :");
		String maker = sc.nextLine();
		System.out.print("게임 장르 :");
		String genre = sc.nextLine();

		if (controller.add(name, maker, genre)) {
			System.out.println("등록완료");
		} else {
			System.out.println("");
		}

	}

	public void deleteGame() {

		System.out.printf("삭제할 게임 이름 :");
		String name = sc.nextLine();

		if (controller.delete(name)) {
			System.out.println("삭제 완료");
		} else {
			System.out.println("해당 게임을 찾을 수 없습니다");
		}

	}

	public void updateGame() {
		
		System.out.print("수정 전 게임 이름 :");
		String name = sc.nextLine();
		System.out.print("수정 후 게임 이름 :");
		String newName = sc.nextLine();
		System.out.print("수정 후 게임 회사 :");
		String newMaker = sc.nextLine();
		System.out.print("수정 후 게임 장르 :");
		String newGenre = sc.nextLine();
		
	}

}
